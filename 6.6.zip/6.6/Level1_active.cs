﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level1_active : MonoBehaviour
{
    public GameObject canvus1;
    public GameObject Level1_solt;
    public GameObject Level1_bunU;
    public GameObject Level1_sugar;
    public GameObject Level1_mill;
    public GameObject Level1_banjuc;

    void Start()
    {
        Destroy(Level1_solt);
        Destroy(Level1_bunU);
        Destroy(Level1_sugar);
        Destroy(Level1_mill);
        Instantiate(Level1_banjuc, new Vector3(77.92f, 0.88f, 45.21f), Quaternion.identity);
        //Instantiate(canvus1, new Vector3(70.7f, 5.328f, 49.08f), Quaternion.identity);
        canvus1.SetActive(true);
    }

    // Update is called once per frame
   
}
