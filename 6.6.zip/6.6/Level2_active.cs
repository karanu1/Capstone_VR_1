﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level2_active : MonoBehaviour
{
    public GameObject canvus2;
    public GameObject Level2_egg;
    public GameObject Level2_east;
    public GameObject Level2_banjuc;


    void Start()
    {
        Destroy(Level2_egg);
        Destroy(Level2_east);
        Instantiate(Level2_banjuc, new Vector3(77.92f, 0.88f, 45.21f), Quaternion.identity);
        Instantiate(canvus2, new Vector3(70.7f, 5.328f, 49.08f), Quaternion.identity);
    }
}
