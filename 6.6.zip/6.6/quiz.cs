﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class quiz : MonoBehaviour
{
    public GameObject can;
    public bool[] collect = new bool[11];
    public int Level = 1;
    // Start is called before the first frame update
    private void Start()
    {
        for (int i = 0; i < 11; i++)
        {
            collect[i] = false;
        }
    }
    public void click()
    {
        collect[Level] = false;
        can.SetActive(false);
        Level++;
    }
    public void Correct()
    {
        collect[Level] = true;
        can.SetActive(false);
        Level++;
    }
}
