﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collect : MonoBehaviour
{
   

    public GameObject Canvus;


    public void Collectt()
    {

        Canvus.SetActive(false);
    }
    public void Tle()
    {

        Canvus.SetActive(false);
    }
}
