﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class boom : MonoBehaviour
{

    public GameObject long_banjuc;
    public GameObject death_banjuc;
    void OnTriggerEnter(Collider other)
    {
        if(other.transform.tag == "banjuc4")
        {
            Destroy(death_banjuc);
            Instantiate(long_banjuc,death_banjuc.transform.position, Quaternion.identity);
        }
    }
}
