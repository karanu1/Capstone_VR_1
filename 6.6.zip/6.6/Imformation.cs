﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Imformation : MonoBehaviour
{
    public GameObject jp;
    public Sprite jpg;
    public Text Imfor_text;
    public Text button_text;
    public int end_count = 0;
    public GameObject Impor;
    public GameObject Imformation_Le4;
    public GameObject circle_banjuc;
    public GameObject iron;

    public Vector3 iron_posi;
    public void daum()
    {
        if (end_count == 1)
        {
            Impor.SetActive(false);
        }
        if (end_count == 0)
        {
            jp.GetComponent<Image>().sprite = jpg;
            Imfor_text.GetComponent<Text>().text = "손가락이 비칠정도로 얇게 잘 늘어나면 잘 된 반죽";
            button_text.GetComponent<Text>().text = "확인";
            end_count++;
        }
       
    }
    public void daum2()
    {
        float distance = 0.547f;
        Imformation_Le4.SetActive(false);
        iron.transform.position = iron_posi;
        for (int i = 0; i < 5; i++)
        {
            Instantiate(circle_banjuc, new Vector3(iron_posi.x - 1.9432f+distance*i, iron_posi.y - 0.25119f, iron_posi.z + 0.70412f), Quaternion.identity);
        }

    }
}
