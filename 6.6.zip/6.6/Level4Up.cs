﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level4Up : checkfun
{
    public bool boll_count = false;
    public bool banjuc3_count = false;
    public GameObject circle_banjuc2;
    public Vector3 iron_position;
    public GameObject iron_pan;
    // Start is called before the first frame update
    private void OnTriggerStay(Collider other)
    {
        if (other.transform.tag == "boll")
        {
            boll_count = true;
        }
        if (other.transform.tag == "banjuc3")
        {
            banjuc3_count = true;
        }
        if((boll_count == true)&&(banjuc3_count == true))
        {
            //  Quiz_mix();
            iron_pan.transform.position = iron_position;
           // float distance2 = 0.547f;
           
            Instantiate(circle_banjuc2, new Vector3(iron_position.x - 1.9432f, iron_position.y - 0.25119f, iron_position.z + 0.70412f), Quaternion.identity);
            can.SetActive(true);
        }
    }
}
