﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level1_active : MonoBehaviour
{
    //퀴즈1 단수 퀴즈 호출 스크립트
    public GameObject lever_1_mill;
    public GameObject lever_1_water;
    public GameObject lever_1_east;
    public GameObject level_1_powder;
    public GameObject level_1_solt;
    public GameObject level_1_sugar;
    public GameObject level_1_bunU;
    public GameObject level_1_egg;

    public GameObject Level1_banjuc;

    void Start()
    {
        Destroy(lever_1_mill);
        Destroy(lever_1_water);
        Destroy(lever_1_eastr);
        Destroy(level_1_powder);
        Destroy(level_1_solt);
        Destroy(level_1_sugar);
        Destroy(level_1_bunU);
        Destroy(level_1_egg);

     //재료 파괴 및 반죽 생성
        Instantiate(Level1_banjuc, new Vector3(77.92f, 0.88f, 45.21f), Quaternion.identity);
        //        Instantiate(Level1_banjuc, new Vector3(77.92f, 0.88f, 45.21f), Quaternion.identity);
        //Instantiate(canvus1, new Vector3(70.7f, 5.328f, 49.08f), Quaternion.identity);
        
    }

    // Update is called once per frame
   
}
