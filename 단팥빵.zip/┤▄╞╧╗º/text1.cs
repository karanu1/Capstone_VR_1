﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class text : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler, IPointerClickHandler
{

    public Color32 m_NormalColor = Color.white;
    public Color32 m_HoverColor = Color.grey;
    public Color32 m_DownColor = Color.white;

    public GameObject text1;
    public GameObject text2;
    public GameObject text3;
    public GameObject quiz2;


    public int count_Level = 1;

    private Image m_Image = null;

    private void Awake()
    {
        m_Image = GetComponent<Image>();
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        m_Image.color = m_HoverColor;
    }

    public void OnPointerExit(PointerEventData eventData)
    {

        m_Image.color = m_NormalColor;
    }
    public void OnPointerDown(PointerEventData eventData)
    {

        m_Image.color = m_DownColor;
    }
    public void OnPointerUp(PointerEventData eventData)
    {
        if (count_Level == 3)
        {
            //최종 반죽 온도가 30
            //반죽을 펼쳐봤을때 얇은 막을 형성하며 잘 펴지면 잘 된 반죽 텍스트
            count_Level++;
            quiz2.SetActive(true);
            text3.SetActive(false);
            
        }
        if (count_Level == 2)
        {
            //1단에서 1분 마가린 재료가 섞이면 3단에서 5분 텍스트
            count_Level++;
            text3.SetActive(true);
            text2.SetActive(false);
        }
        if (count_Level == 1)
        {
            //반죽온도 30도 텍스트
            count_Level++;
            text1.SetActive(false);
        }
    }
    public void OnPointerClick(PointerEventData eventData)
    {
        print("Click");
        m_Image.color = m_HoverColor;
    }
}
