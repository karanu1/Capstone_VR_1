﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class checkfun : MonoBehaviour
{
    public GameObject mill;
    public GameObject water;
    public GameObject east;
    public GameObject powder;
    public GameObject solt;
    public GameObject sugar;
    public GameObject magarine;
    public GameObject bunU;
    public GameObject egg;

//   public GameObject banjuc;
//  public GameObject banjuc2;
//   public GameObject can;
//   public GameObject banjuc3;
//    public GameObject Imformation;

    public GameObject mixing;
    public Text[] but_text = new Text[4];
    public Text can_text;
    public Button[] but = new Button[4];
    public int count = 0;
    public bool[] check_sum = new bool[14];


    public bool mill_count = false;
    public bool water_count = false;
    public bool east_count = false;
    public bool solt_count = false;
    public bool sugar_count = false;
    public bool bunU_count = false;
    public bool egg_count = false;
    public bool powder_count = false;

    public bool magarine_count = false;


    public Vector3[] posi = new Vector3[6];
    public int[] quiz_position = new int[4];

    void Start()
    {
        for(int i=0; i<14; i++)
        {
            check_sum[i] = false;
        }
    }
  
    private void OnTriggerEnter(Collider collision)
    {
        if(collision.gameObject.tag == "mill")
        {
            mill_count = true;
        }
        if (collision.gameObject.tag == "water")
        {
            water_count = true;
        }
        if (collision.gameObject.tag == "east")
        {
            east_count = true;
        }
        if (collision.gameObject.tag == "solt")
        {
            solt_count = true;
        }
        if (collision.gameObject.tag == "sugar")
        {
            sugar_count = true;
        }
        if (collision.gameObject.tag == "bunU")
        {
            bunU_count = true;
        }
        if (collision.gameObject.tag == "egg")
        {
            egg_count = true;
        }
        if ((collision.gameObject.tag == "shortning") && (count == 2))
        {
            shortning_count = true;
            Destroy(GameObject.FindGameObjectWithTag("banjuc2"), 0f);
            Destroy(GameObject.FindGameObjectWithTag("shortning"), 0f);
            Instantiate(banjuc3, new Vector3(77.92f, 0.88f, 45.21f), Quaternion.identity);
            Imformation.SetActive(true);
            count++;
        }
        if ((mill_count == true) || (solt_count == true) || (sugar_count == true) 
            || (bunU_count == true) || (egg_count == true) || (powder_count == true) || (water_count == true)) //1단계
        {
            mixing.SetActive(true); //믹싱 시작 버튼 생성
        }
        if (magarine_count == true) //2단계 (클린업 단계에서 마가린)
        {
            mixing.SetActive(true); //믹싱 시작 버튼 활성화
          //  Quiz_mix();
          //  can.SetActive(true);
        
        }

    }
    void check()
    {
        if ((mill_count == true) && (solt_count == true) && (sugar_count == true)
           && (bunU_count == true) && (egg_count == true) && (powder_count == true) && (water_count == true)) //1단계
        {
            check_sum[0] = true;
        }
    }
}
