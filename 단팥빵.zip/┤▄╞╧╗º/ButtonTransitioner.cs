﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class ButtonTransitioner : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler, IPointerClickHandler
{
    //퀴즈 정답 버튼
    public Color32 m_NormalColor = Color.white;
    public Color32 m_HoverColor = Color.grey;
    public Color32 m_DownColor = Color.white;
    public GameObject quiz1;
    public GameObject text1;
    public GameObject Level_1;


    public int count_Level = 1;

    private Image m_Image = null;

    private void Awake()
    {
        m_Image = GetComponent<Image>();
    }

    public void OnPointerEnter(PointerEventData eventData)
    {

    }

    public void OnPointerExit(PointerEventData eventData)
    {

        m_Image.color = m_HoverColor;
    }
    public void OnPointerDown(PointerEventData eventData)
    {

        m_Image.color = m_DownColor;
    }
    public void OnPointerUp(PointerEventData eventData)
    {
        if (count_Level == 2)
        {
            //두번째 퀴즈 답 선택(온도, 습도, 시간)
            Instantiate(Level1_banjuc, new Vector3(77.92f, 0.88f, 45.21f), Quaternion.identity);
        }
        if (count_Level == 1)
        {
            //첫번째 퀴즈 답 선택 버튼 스크립트
            text1.SetActive(true); //반죽 온도 텍스트 호출
            count_Level++;
            Level_1.SetActive(true);// 재료 파괴 및 반죽 생성 스크립트 호출
            quiz1.SetActive(false);
            //Destroy(GameObject.FindGameObjectWithTag("mix"), 0f);
        }


    }
    public void OnPointerClick(PointerEventData eventData)
    {
        print("Click");
        m_Image.color = m_HoverColor;
    }
}
